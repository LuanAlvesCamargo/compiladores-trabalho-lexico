#include <iostream>
#include "LexerTest.h"

using namespace std;

int main() {
    LexerTest::executarTestes();
    return 0;
}
