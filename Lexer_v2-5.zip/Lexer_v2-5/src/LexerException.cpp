#include "LexerException.h"

LexerException::LexerException()
{
    //ctor
}

LexerException::~LexerException()
{
    //dtor
}
